# CanvasAPIUtils

A small utility package to simplify Canvas LMS API interactions using the `canvasapi` Python client.

## Installation

```bash
pip install canvasapiutils
